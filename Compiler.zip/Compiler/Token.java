public class Token {
    private Scanner.TokenType type;
    private String value;

    public Token(Scanner.TokenType type, String value) {
        this.type = type;
        this.value = value;
    }

    public Scanner.TokenType getType() {
        return type;
    }

    public String getValue() {
        return value;
    }

    @Override
    public String toString() {
        return "Token{type=" + type + ", value='" + value + "'}";
    }
} 