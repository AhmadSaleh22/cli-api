import java.io.*;
import java.util.*;

/**
 * Compiler Project - Phase 1: Lexical Analyzer
 * Team Members:
 * 1. [Student Name 1]
 * 2. [Student Name 2]
 * 3. [Student Name 3]
 */
public class Scanner {
    private String input;
    private int currentPosition;
    private List<Token> tokens;
    
    // Token types
    public enum TokenType {
        NUMBER,
        IDENTIFIER,
        OPERATOR,
        KEYWORD,
        DELIMITER,
        EOF
    }

    // Keywords in the language
    private static final Set<String> keywords = new HashSet<>(Arrays.asList(
        "if", "else", "while", "int", "float", "return", "void"
    ));

    // Operators in the language
    private static final Set<String> operators = new HashSet<>(Arrays.asList(
        "+", "-", "*", "/", "=", "==", "<", ">", "<=", ">="
    ));

    public Scanner(String input) {
        this.input = input;
        this.currentPosition = 0;
        this.tokens = new ArrayList<>();
    }

    public List<Token> scanTokens() {
        while (currentPosition < input.length()) {
            char currentChar = input.charAt(currentPosition);
            
            // Skip whitespace
            if (Character.isWhitespace(currentChar)) {
                currentPosition++;
                continue;
            }

            // Numbers
            if (Character.isDigit(currentChar)) {
                scanNumber();
            }
            // Identifiers and Keywords
            else if (Character.isLetter(currentChar)) {
                scanIdentifier();
            }
            // Operators
            else if (isOperatorChar(currentChar)) {
                scanOperator();
            }
            // Delimiters
            else if (isDelimiter(currentChar)) {
                tokens.add(new Token(TokenType.DELIMITER, String.valueOf(currentChar)));
                currentPosition++;
            }
            else {
                // Invalid character
                System.err.println("Error: Invalid character '" + currentChar + "' at position " + currentPosition);
                currentPosition++;
            }
        }
        
        tokens.add(new Token(TokenType.EOF, ""));
        return tokens;
    }

    private void scanNumber() {
        StringBuilder number = new StringBuilder();
        while (currentPosition < input.length() && 
               (Character.isDigit(input.charAt(currentPosition)) || input.charAt(currentPosition) == '.')) {
            number.append(input.charAt(currentPosition));
            currentPosition++;
        }
        tokens.add(new Token(TokenType.NUMBER, number.toString()));
    }

    private void scanIdentifier() {
        StringBuilder identifier = new StringBuilder();
        while (currentPosition < input.length() && 
               (Character.isLetterOrDigit(input.charAt(currentPosition)) || input.charAt(currentPosition) == '_')) {
            identifier.append(input.charAt(currentPosition));
            currentPosition++;
        }
        String word = identifier.toString();
        if (keywords.contains(word)) {
            tokens.add(new Token(TokenType.KEYWORD, word));
        } else {
            tokens.add(new Token(TokenType.IDENTIFIER, word));
        }
    }

    private void scanOperator() {
        StringBuilder operator = new StringBuilder();
        while (currentPosition < input.length() && isOperatorChar(input.charAt(currentPosition))) {
            operator.append(input.charAt(currentPosition));
            currentPosition++;
        }
        if (operators.contains(operator.toString())) {
            tokens.add(new Token(TokenType.OPERATOR, operator.toString()));
        } else {
            System.err.println("Error: Invalid operator '" + operator + "' at position " + currentPosition);
        }
    }

    private boolean isOperatorChar(char c) {
        return "+-*/=<>".indexOf(c) != -1;
    }

    private boolean isDelimiter(char c) {
        return "(){}[];,".indexOf(c) != -1;
    }
} 