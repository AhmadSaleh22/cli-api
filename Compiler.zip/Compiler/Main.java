public class Main {
    public static void main(String[] args) {
        String testInput = "int main() {\n" +
                          "    int x = 42;\n" +
                          "    if (x <= 50) {\n" +
                          "        return x;\n" +
                          "    }\n" +
                          "    return 0;\n" +
                          "}";

        Scanner scanner = new Scanner(testInput);
        List<Token> tokens = scanner.scanTokens();
        
        for (Token token : tokens) {
            System.out.println(token);
        }
    }
}